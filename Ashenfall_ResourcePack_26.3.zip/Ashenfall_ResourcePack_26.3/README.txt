Ashenfall SMP Resource Pack — Minecraft Java 26.3

Includes BattleJuice - The Ascension, trimmed to 00:00–03:04 (184 seconds), as OGG Vorbis.
Sound event registered: ashenfall:boss_phase4

This pack does not itself start or loop music. The Paper plugin must play the custom sound event on phase 4 entry and restart it every 184 seconds, then stop it when the boss fight ends. Confirm the artist's permission includes redistributing the audio file inside the downloadable resource pack.

Server distribution:
1. Upload this ZIP to a direct-download HTTPS URL.
2. Set resource-pack=<direct URL> in server.properties.
3. Set resource-pack-sha1=<SHA-1 of the exact ZIP bytes>.
4. Set require-resource-pack=true if the pack must be accepted to join.
5. Restart and test with a clean client.
